const test = require("node:test");
const assert = require("node:assert/strict");
const { FIORI, petaliCasuali, risultato, etichettaPetalo } = require("../www/fiori.js");

test("ci sono 15 fiori con id unici e campi completi", () => {
  assert.equal(FIORI.length, 15);
  assert.equal(new Set(FIORI.map((f) => f.id)).size, 15);
  for (const f of FIORI) {
    assert.ok(f.nome.it && f.nome.en && f.nome.es && f.significato.it && f.significato.en && f.significato.es, f.id);
    assert.ok(f.messaggi.mama.en && f.messaggi.mama.es && f.messaggi.nonMama.en && f.messaggi.nonMama.es, f.id);
  }
});

test("il numero di petali sta sempre tra 9 e 21", () => {
  for (let i = 0; i < 500; i++) {
    const n = petaliCasuali();
    assert.ok(n >= 9 && n <= 21, String(n));
  }
});

test("il risultato dipende dalla parita' del numero di petali", () => {
  assert.equal(risultato(9), "M'ama");
  assert.equal(risultato(10), "Non m'ama");
  assert.equal(risultato(21), "M'ama");
});

test("il primo petalo e' 'm'ama' e l'alternanza prosegue", () => {
  assert.equal(etichettaPetalo(1), "M'ama");
  assert.equal(etichettaPetalo(2), "Non m'ama");
  assert.equal(etichettaPetalo(3), "M'ama");
});

const { numeroPerRisultato } = require("../www/fiori.js");

test("l'ultimo petalo dà il risultato voluto, qualunque sia la partenza", () => {
  for (const primo of [true, false]) {
    for (const voluto of ["M'ama", "Non m'ama"]) {
      for (let ultimo = 9; ultimo <= 21; ultimo++) {
        for (let k = 0; k < 40; k++) {
          const n = numeroPerRisultato(primo, voluto, ultimo);
          assert.ok(n >= 9 && n <= 21, "fuori range " + n);
          assert.notEqual(n, ultimo);
          const ultimaEtichetta = (n % 2 === 1) === primo ? "M'ama" : "Non m'ama";
          assert.equal(ultimaEtichetta, voluto, "partenza " + primo + " voluto " + voluto + " n " + n);
        }
      }
    }
  }
});
